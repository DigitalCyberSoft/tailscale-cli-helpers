# Tailscale CLI helpers
if [ -f /usr/share/tailscale-cli-helpers/tailscale-ssh-helper.sh ]; then
    . /usr/share/tailscale-cli-helpers/tailscale-ssh-helper.sh
fi
